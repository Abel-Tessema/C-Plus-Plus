#include <iostream>
using namespace std;

int main() {

    int x = 10;
    // x = x + 5;
    // x = x - 5;
    // x = x * 5;
    // x = x / 5;
    // x = x % 5;

    // x = x + 1;
    // x++;
    // x--;

    // int y = x++; // x = 11, y = 10

    int z = ++x; // x = 11, z = 11

    // cout << x << endl;
    // cout << y << endl;
    // cout << x << endl;

    cout << z << endl;

}