#include <iostream>
using namespace std;

int main() {

    // This is a comment.
    /*
     * This is
     * a multi-line
     * comment.
    */

    return 0;
}