#include <iostream>
using namespace std;

int main() {

    int file_size; // Snake Case
    int FileSize; // Pascal Case - for classes
    int fileSize; // Camel Case - for variables and constants
    int iFileSize; // Hungarian Notation

    // cout << "";
    return 0;

}