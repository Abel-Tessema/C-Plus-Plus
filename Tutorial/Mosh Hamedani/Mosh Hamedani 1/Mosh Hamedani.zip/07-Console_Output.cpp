#include <iostream>
using namespace std;

int main() {

    int x = 10;
    int y = 20;

    // cout << "x = ";
    // cout << x << endl;
    // cout << "x = " << x << endl;

    cout << "x = " << x << endl
         << "y = " << y << endl;
    return 0;

}