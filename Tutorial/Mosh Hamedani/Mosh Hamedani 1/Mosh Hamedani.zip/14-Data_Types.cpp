#include <iostream>
using namespace std;

int main () {
    /*
      * double price = 99.99;
      * float interestRate = 3.67F;
      * long fileSize = 90000L;
      * char letter = 'a';
      * bool isValid = false;
    */

    /*
      * auto price = 99.99;
      * auto interestRate = 3.67F;
      * auto fileSize = 90000L;
      * auto letter = 'a';
      * auto isValid = true;
    */

    // int number = 1.9;
    // int number {1.9};
    // double number {1.9};
    int number {};

    cout << number << endl;

    return 0;

}