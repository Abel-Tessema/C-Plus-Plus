#include <iostream>
using namespace std;

int main() {

    // int x = 10;
    // double x = 10;

    int x = 10;
    int y = 3;

    // int z = x + y;
    // int z = x - y;
    // int z = x * y;
    // int z = x / y;
    // double z = x / y;

    int z = x % y;

    cout << z << endl;
    return 0;

}