#include <iostream>
using namespace std;

int main() {

    // double x = 1 + 2 * 3;
    // double x = (1 + 2) * 3;
    double x = 10;
    double y = 5;

    double z = (x + 10) / (3 * y);
    
    cout << z << endl;
    return 0;

}