#include <iostream>
using namespace std;

int main() {

    /*
      * int number1 = 1'000'000;
      * short number2 = number1;
    */
   
    short number1 = 100;
    int number2 = number1;

    cout << number2 << endl;

    return 0;

}