#include <iostream>
#include <cmath>
using namespace std;

int main() {

    // int result = floor(2.8);
    double result = pow(7, 3.2);
    cout << result << endl;

    return 0;

}