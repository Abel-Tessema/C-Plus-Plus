#include <iostream>
using namespace std;

int main() {

    /*
      * int number = 0b11111111;
      * int number = 0xFF;
      * unsigned int number = -255;
    */
    
    unsigned number = 0;
    number--;
    cout << number << endl;

    return 0;

}