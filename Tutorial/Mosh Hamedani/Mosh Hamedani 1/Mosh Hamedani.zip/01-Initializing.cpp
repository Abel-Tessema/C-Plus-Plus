#include <iostream>
using namespace std;

int main() {
	
	int file_size = 0;
	int counter = 0;
	double sales = 9.99;
	cout << file_size <<endl;
	return 0;

}