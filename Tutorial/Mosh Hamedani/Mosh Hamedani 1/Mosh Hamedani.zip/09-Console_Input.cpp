#include <iostream>
using namespace std;

int main() {

    /*
    cout << "Enter a value: ";
    double value;
    cin >> value;
    cout << value << endl;
    */

    cout << "Enter values for x and y consecutively: ";
    double x;
    double y;
    /* cin >> x;
       cin >> y; */
    cin >> x >> y;
    cout << x + y << endl;

}