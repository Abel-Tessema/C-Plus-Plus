#include <iostream>
using namespace std;

int main() {
    bool isNewUser = true;
    cout << boolalpha << isNewUser << endl;
    cout << noboolalpha << isNewUser << endl;
    return 0;
}