#include <iostream>
using namespace std;

int main() {

    const double pi = 3.14159265;
    // pi = 3.5;
	cout << pi <<endl;
	return 0;

}